#!/bin/sh
#
# build-zerotrustbsd.sh
# 🛡️ A simple ISO builder script for ZeroTrustBSD
#
# USAGE:
#   chmod +x build-zerotrustbsd.sh
#   ./build-zerotrustbsd.sh
#
set -e

echo "🛠  Starting ZeroTrustBSD ISO build..."

WORKDIR="ztbsd-iso"
ROOTFS="$WORKDIR/rootfs"
ISO_NAME="zerotrustbsd-$(date +%Y%m%d).iso"

rm -rf "$WORKDIR"
mkdir -p "$ROOTFS/etc"

echo "Welcome to ZeroTrustBSD (Mocked RootFS)" > "$ROOTFS/README.txt"
echo "hostname=zerotrustbsd" > "$ROOTFS/etc/hostname.ztbsd"

echo "📦 Creating ISO image..."
xorriso -as mkisofs -o "$ISO_NAME" -R -J "$ROOTFS"

echo "✅ ISO created: $ISO_NAME"