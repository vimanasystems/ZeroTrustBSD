# Welcome to ZeroTrustBSD
Open-source firewall and compliance OS based on OpenBSD.